﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace RBGame
{
    /// <summary>
    /// Это вынес отдельно. Должно быть одинаковым для всех проектов
    /// </summary>
    public class GameContextBase : MonoBehaviour
    {
     
    }
}